const express = require('express');
const path = require('path');

const app = express();

const DIST_DIR = path.join(__dirname, 'dist/essentials');
app.use(express.static(DIST_DIR));

app.get('*', (req, res) => {
    res.sendFile(path.join(DIST_DIR, 'index.html'));
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});