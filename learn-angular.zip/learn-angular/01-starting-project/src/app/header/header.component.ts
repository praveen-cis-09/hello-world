import { Component } from '@angular/core';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css',
})
export class HeaderComponent {}


// template key can also be passed
// template :'<h1>H1 header is here</h1>'
// if you are using an angular version smaller than 19 you can use standalone key
// 