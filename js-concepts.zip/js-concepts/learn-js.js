function checkWhetherAStringIsPalindrome() {
  let str = "nayan";
  let outStr = "";
  for (let ch = str.length - 1; ch >= 0; ch--) {
    outStr += str[ch];
  }
  if (str === outStr) {
    console.log("Palindrome");
  } else {
    console.log("Not Palindrome");
  }
};

function computeLongestWordFromAString() {
  let sentence = "I am working as a software developer";
  let obj = {};
  let arr = sentence.split(" ");
  for (let item of arr) {
    obj[item] = item.length;
  }
  let maxLength = Math.max(...Object.values(obj));
  let maxWord = Object.keys(obj).find((key) => obj[key] === maxLength);
  console.log(maxWord);
};

const removeDuplicatesFromArray = () => {
  let inputArr = [1, 2, 3, 4, 5, 1, 2, 3, 5];
  return Array.from(new Set(inputArr));
};

function reverseAString() {
  let inputStr = "reverse a string in js";
  let outStr = "";
  for (let i = inputStr.length - 1; i >= 0; i--) {
    outStr += inputStr[i];
  }
  return outStr;
};


function checkWhetherItemsAreSquared(a,b){
    
};

let firstContainer = [1,2,3,4,5];
let secondContainer = [1,4,9,16,25];

console.log('check item function call',checkWhetherItemsAreSquared(firstContainer,secondContainer))