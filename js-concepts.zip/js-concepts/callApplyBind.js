let userObj = {
    firstName : 'Juan',
    lastName :'Whitby'
};

let userObj2 = {
    firstName: 'Abdullah',
    lastName :'Elquerish'
};

let printUserInfo = function(homeTown,state) {
    console.log(`${this.firstName} ${this.lastName} from ${homeTown} with state ${state}`)
};

//function borrowing
printUserInfo.call(userObj,"Dubai","XYZ");

printUserInfo.call(userObj2,"South Arabia","PQR");


//The difference b/w call and apply is the way of passing the arguments

printUserInfo.apply(userObj,["Dubai","PQR"]);
