//Debouncing in JavaScript
let counter = 0;
const getData = () => {
    //calls an API and gets Data
    console.log("Fetching data.....", counter++);
};

const debouncing = function (fn, delay) {
    let timer;
    return function () {
        let context = this;
        args = arguments;
        clearInterval(timer);
        timer = setTimeout(() => {
            getData.apply(context, arguments);
        }, delay);
    }
};

// Only do some magic and only call getData method when the difference
// of time b/w 2 key press events are greater than 300 or equals 300.
const betterFunction = debouncing(getData, 300);

