// What is a Polyfill
// It is a browswer fallback , that they do'nt have bind function.
//Own implementation of a bind function 

let userObj3 = {
    firstName: 'Praveen',
    lastName:'Sunhare'
};

let printFullNameInfo = function (){
    console.log(`${this.firstName} ${this.lastName}`);
};

let printNameOutput = printFullNameInfo.bind(userObj3);

printNameOutput();

//Own implementation for polyfills

Function.prototype.mybind = function (...args){
    let obj = this,
     params = args.splice(1);
    return function (...args2){
        obj.apply(args[0],[...params,...args2])
    }
}

let myBindOutput = printFullNameInfo.mybind(userObj3);
myBindOutput()