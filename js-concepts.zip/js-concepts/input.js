let inputObj = {
    "categories": {
        "electronics": {
            "mobile": {
                "samsung": {
                    "galaxy": "M31"
                }
            },
            "refrigerator": {
                "LG": {
                    "convertible": "modelname"
                },
                "Samsung": {
                    "convertible": "modelname"
                }
            },
            "washingmachine": {
                "LG": "modelname LG",
                "Samsung": "modelname samsung"
            }
        },
        "Clothing": {
            "Men": {
                "Jeans": ["Jack & Jones", "Spykar", "Puma"]
            },
            "Women": {
                "Jeans": ["Jack & Jones", "Spykar", "Puma"]
            }
        }
    }
};


const recurseFunction = (obj,initialKey='',stringAdd="-") => {
    let outObj = {};

    for (let objKey in obj){
        let newKey = initialKey ? `${initialKey}${stringAdd}${objKey}` : objKey;
        if(typeof obj[objKey] == "object"){
            Object.assign(outObj,recurseFunction(obj[objKey],newKey))
        } else {
            outObj[newKey] = obj[objKey];
        }
    }
    return outObj;
}


let output = recurseFunction(inputObj);
console.log('output',output);

let container = ['Looped',
    'Pay',
    'Loop',
    'Poodle',
    'Yap',
    'Pool',
]