let arr = [1, 2, 3,0,0];
arr.slice(5,1, 6)
console.log(arr)