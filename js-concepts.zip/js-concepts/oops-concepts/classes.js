//1. using es6

class DiscountCouponCode {
    constructor(couponName, couponCode, couponPer, couponStatus) {
        this.couponName = couponName;
        this.couponCode = couponCode;
        this.couponPer = couponPer;
        this.couponStatus = couponStatus;
    };

    getCouponDetails() {
        return `The coupon details are ${this.couponName} , ${this.couponCode} , ${this.couponPer} with status ${this.couponStatus}`
    }
};

let couponObjMag = new DiscountCouponCode('coupon-code-for-magazine', 'FISRTMAG50', 50, true);
let couponObjNews = new DiscountCouponCode('coupon-code-for-newspaper', 'FISRTNEWS20', 20, false);
// console.log('couponMagDetails',couponObjMag.getCouponDetails())

//2.  use traditional way of js
function User(fName,lName){
    this.fName = fName;
    this.lName = lName;
};

User.prototype.getUserInfo =  function (){
    return `User info are as ${this.fName} & ${this.lName}`;
};

let userObj = new User('sam***','at****');

console.log(userObj.getUserInfo());