// Object literal

let patient = {
    firstName: 'alice',
    lastName: 'smith',

    getPatientDetails: function () {
        return `The person details are ${this.firstName} and ${this.lastName}`
    },

    contactDetailObj: {
        city: 'South Carolina',
        number: '9098763536'
    }
};


console.log(patient.getPatientDetails());


// Using object constructor

function employee(empId,empName,empDesg){
    this.empId = empId;
    this.empName= empName;
    this.empDesg = empDesg;
};

let e1 = new employee('sp01','juan','ceo');
let e2 = new employee('sp02','jacob','mini-ceo');
let e3 = new employee('sp03','reem','assistant-designer');

console.log(e1,e2,e3)


let me = Object.create(patient);
me = {...patient};

console.log(me)
